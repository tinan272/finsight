// app.d.ts
/// <reference types="nativewind/types" />

// Declare image module types for TypeScript
declare module "*.png";
declare module "*.jpg";
declare module "*.jpeg";
declare module "*.svg";
